# Etapa 1: preparar o Supabase

O arquivo `migrations/202610090001_initial_schema.sql` cria as tabelas do SaaS e ativa Row Level Security (RLS) para cada conta.

## Como aplicar

1. Abra o projeto correto no Supabase Dashboard.
2. Entre em **SQL Editor** e crie uma consulta nova.
3. Copie o conteúdo de `migrations/202610090001_initial_schema.sql`, cole e execute.
4. Confirme que as tabelas `profiles`, `categories`, `transactions`, `monthly_budgets`, `cards`, `card_monthly_budgets`, `goals` e `user_subscriptions` aparecem no Database.
5. Ainda não publique o arquivo de migração de dados pessoais no GitHub.

A migração cria cada novo usuário com o papel `user`. Depois de criar sua conta no app (etapa de login), promova apenas sua conta a administradora. No SQL Editor, substitua o endereço de e-mail e execute:

```sql
update public.profiles
set role = 'admin', plan_key = 'owner', subscription_status = 'active'
where user_id = (select id from auth.users where email = 'SEU_EMAIL');
```

## Credenciais do app na etapa seguinte

Para conectar o front-end, serão necessários apenas o **Project URL** e a **publishable key** (em projetos antigos pode aparecer como `anon` key). A chave `service_role` ou qualquer chave `secret` nunca deve ir para HTML, JavaScript, GitHub ou para o celular do usuário.

As tabelas financeiras aceitam operações somente quando `user_id` coincide com a conta autenticada. A role de administrador pode consultar a lista de perfis, mas não recebe acesso direto às transações de clientes. O acesso financeiro do usuário pode ser bloqueado pelo status `suspended`.

O schema não processa pagamentos ainda. O Mercado Pago entra em uma etapa posterior, por uma função de servidor que valida webhooks e atualiza assinaturas.
