-- Meu Financeiro SaaS: esquema inicial para Supabase/PostgreSQL.
-- Execute pelo Supabase Dashboard > SQL Editor depois de conferir o projeto.

create schema if not exists private;
revoke all on schema private from public;
grant usage on schema private to authenticated;

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  email text not null default '',
  display_name text not null default '',
  role text not null default 'user' check (role in ('user', 'admin')),
  plan_key text not null default 'free',
  subscription_status text not null default 'active'
    check (subscription_status in ('trial', 'active', 'past_due', 'canceled', 'suspended')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('receita', 'despesa', 'investimento')),
  name text not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  unique (user_id, kind, name),
  unique (user_id, id)
);

create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('receita', 'despesa', 'investimento')),
  description text not null check (length(trim(description)) between 1 and 120),
  amount numeric(14,2) not null check (amount > 0),
  category_name text not null,
  occurred_on date not null,
  due_on date,
  paid_on date,
  is_paid boolean not null default true,
  payment_method text,
  card_name text,
  installment text,
  note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.monthly_budgets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('receita', 'despesa')),
  category_name text not null,
  budget_year smallint not null check (budget_year between 2000 and 2200),
  budget_month smallint not null check (budget_month between 1 and 12),
  planned_amount numeric(14,2) not null default 0 check (planned_amount >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, kind, category_name, budget_year, budget_month)
);

create table if not exists public.cards (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (length(trim(name)) between 1 and 60),
  created_at timestamptz not null default now(),
  unique (user_id, name),
  unique (user_id, id)
);

create table if not exists public.card_monthly_budgets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  card_id uuid not null,
  budget_year smallint not null check (budget_year between 2000 and 2200),
  budget_month smallint not null check (budget_month between 1 and 12),
  planned_amount numeric(14,2) not null default 0 check (planned_amount >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, card_id, budget_year, budget_month),
  foreign key (user_id, card_id) references public.cards(user_id, id) on delete cascade
);

create table if not exists public.goals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (length(trim(name)) between 1 and 80),
  target_amount numeric(14,2) not null check (target_amount > 0),
  saved_amount numeric(14,2) not null default 0 check (saved_amount >= 0),
  target_date date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Metadados de assinatura. Alterações de plano/status serão feitas pelo servidor,
-- após confirmar eventos do provedor de pagamento.
create table if not exists public.user_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  provider text check (provider in ('mercado_pago')),
  provider_customer_id text,
  provider_subscription_id text,
  plan_key text not null default 'free',
  status text not null default 'trial'
    check (status in ('trial', 'active', 'past_due', 'canceled', 'suspended')),
  current_period_end timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.admin_audit_log (
  id uuid primary key default gen_random_uuid(),
  actor_user_id uuid references auth.users(id) on delete set null,
  action text not null,
  target_user_id uuid references auth.users(id) on delete set null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function private.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.profiles p
    where p.user_id = (select auth.uid())
      and p.role = 'admin'
  );
$$;
revoke all on function private.is_admin() from public, anon;
grant execute on function private.is_admin() to authenticated;

create or replace function private.account_is_enabled()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.profiles p
    where p.user_id = (select auth.uid())
      and p.subscription_status <> 'suspended'
  );
$$;
revoke all on function private.account_is_enabled() from public, anon;
grant execute on function private.account_is_enabled() to authenticated;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (user_id, email, display_name)
  values (
    new.id,
    coalesce(new.email, ''),
    coalesce(new.raw_user_meta_data ->> 'name', new.raw_user_meta_data ->> 'full_name', '')
  )
  on conflict (user_id) do nothing;
  return new;
end;
$$;
revoke all on function public.handle_new_user() from public, anon, authenticated;

create or replace function public.handle_user_email_update()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  update public.profiles
  set email = coalesce(new.email, ''), updated_at = now()
  where user_id = new.id;
  return new;
end;
$$;
revoke all on function public.handle_user_email_update() from public, anon, authenticated;

drop trigger if exists on_auth_user_email_updated on auth.users;
create trigger on_auth_user_email_updated
  after update of email on auth.users
  for each row when (old.email is distinct from new.email)
  execute procedure public.handle_user_email_update();

create or replace function private.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

create index if not exists transactions_user_date_idx
  on public.transactions (user_id, occurred_on desc);
create index if not exists transactions_user_kind_idx
  on public.transactions (user_id, kind, occurred_on desc);
create index if not exists budgets_user_period_idx
  on public.monthly_budgets (user_id, budget_year, budget_month);
create index if not exists cards_user_idx on public.cards (user_id);
create index if not exists goals_user_idx on public.goals (user_id);

do $$
declare
  table_name text;
begin
  foreach table_name in array array[
    'profiles', 'transactions', 'monthly_budgets', 'card_monthly_budgets',
    'user_subscriptions', 'goals'
  ] loop
    execute format('drop trigger if exists set_updated_at on public.%I', table_name);
    execute format(
      'create trigger set_updated_at before update on public.%I for each row execute procedure private.set_updated_at()',
      table_name
    );
  end loop;
end $$;

alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.transactions enable row level security;
alter table public.monthly_budgets enable row level security;
alter table public.cards enable row level security;
alter table public.card_monthly_budgets enable row level security;
alter table public.goals enable row level security;
alter table public.user_subscriptions enable row level security;
alter table public.admin_audit_log enable row level security;

drop policy if exists "profiles_read_self_or_admin" on public.profiles;
create policy "profiles_read_self_or_admin"
  on public.profiles for select to authenticated
  using ((user_id = (select auth.uid()) and (select private.account_is_enabled())) or (select private.is_admin()));

-- Não existe política de escrita direta para profiles, user_subscriptions ou
-- admin_audit_log. Papel de admin e status de assinatura não podem ser alterados
-- pelo cliente/browser.
grant select on public.profiles to authenticated;
revoke insert, update, delete on public.profiles from anon, authenticated;

do $$
declare
  table_name text;
begin
  foreach table_name in array array[
    'categories', 'transactions', 'monthly_budgets', 'cards',
    'card_monthly_budgets', 'goals'
  ] loop
    execute format('drop policy if exists "owner_all_%1$s" on public.%1$I', table_name);
    execute format(
      'create policy "owner_all_%1$s" on public.%1$I for all to authenticated using (user_id = (select auth.uid()) and (select private.account_is_enabled())) with check (user_id = (select auth.uid()) and (select private.account_is_enabled()))',
      table_name
    );
    execute format('grant select, insert, update, delete on public.%I to authenticated', table_name);
    execute format('revoke all on public.%I from anon', table_name);
  end loop;
end $$;

drop policy if exists "subscription_read_self" on public.user_subscriptions;
create policy "subscription_read_self"
  on public.user_subscriptions for select to authenticated
  using (user_id = (select auth.uid()) and (select private.account_is_enabled()));
grant select on public.user_subscriptions to authenticated;
revoke insert, update, delete on public.user_subscriptions from anon, authenticated;

-- O painel administrativo não recebe permissão para ler as tabelas financeiras.
revoke all on public.admin_audit_log from anon, authenticated;

-- Promova a primeira conta proprietária somente depois do primeiro cadastro:
-- update public.profiles
-- set role = 'admin', plan_key = 'owner', subscription_status = 'active'
-- where user_id = (select id from auth.users where email = 'SEU_EMAIL');

